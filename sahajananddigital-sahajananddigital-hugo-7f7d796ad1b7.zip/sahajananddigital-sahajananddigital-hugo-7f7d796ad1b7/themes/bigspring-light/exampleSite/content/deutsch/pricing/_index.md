---
title: "Preise"
subtitle: ""
# meta description
description: "Dies ist die Metabeschreibung"
draft: false

basic:
  name : "Basis Plan"
  price: "€49"
  price_per : "Monat"
  info : "Ideal für KMUs"
  services:
  - "Express Service"
  - "Customs Clearance"
  - "Time-Critical Services"
  button:
    enable : true
    label : "Kostenlos starten"
    link : "#"
    
professional:
  name : "Professional Plan"
  price: "€49"
  price_per : "Monat"
  info : "Ideal für Professionals"
  services:
  - "Express Service"
  - "Customs Clearance"
  - "Time-Critical Services"
  - "Cloud Service"
  - "Best Dashboard"
  button:
    enable : true
    label : "Kostenlos starten"
    link : "#"
    
business:
  name : "Business Plan"
  price: "€49"
  price_per : "Monat"
  info : "Ideal für Unternehmen"
  services:
  - "Express Service"
  - "Customs Clearance"
  - "Time-Critical Services"
  button:
    enable : true
    label : "Kostenlos starten"
    link : "#"

call_to_action:
  enable : true
  title : "Need a larger plan?"
  image : "images/cta.svg"
  content : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Consequat tristique eget amet, tempus eu at consecttur."
  button:
    enable : true
    label : "Contact Us"
    link : "contact/"
---