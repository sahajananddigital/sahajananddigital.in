---
title: "Services"
subtitle: ""
# meta description
description: "This is meta description"
draft: false

basic:
  name : "SEO / Digital Marketing"
  price: "1st"
  price_per : " On Google"
  info : "Get Website more reach"
  services:
  - "SEO"
  - "Email Marketing"
  - "Social Media Marketing"
  - "Copy Writing"
  - "Google Ads"
  - "Facebook Ads"
  - "Apps Marketing"
  button:
    enable : true
    label : "Get Free Consultation"
    link : "contact"
    
professional:
  name : "Web Development"
  price: "1st"
  price_per : "on Performance"
  info : ""
  services:
  - "Express Service"
  - "Customs Clearance"
  - "Time-Critical Services"
  - "Cloud Service"
  - "Best Dashboard"
  button:
    enable : true
    label : "Get started for free"
    link : "#"
    
business:
  name : "Mobile App Development"
  price: "$49"
  price_per : "month"
  info : "Best For Large Individuals"
  services:
  - "Express Service"
  - "Customs Clearance"
  - "Time-Critical Services"
  button:
    enable : true
    label : "Get started for free"
    link : "#"

call_to_action:
  enable : true
  title : "Need a larger plan?"
  image : "images/cta.svg"
  content : "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Consequat tristique eget amet, tempus eu at consecttur."
  button:
    enable : true
    label : "Contact Us"
    link : "contact"
---